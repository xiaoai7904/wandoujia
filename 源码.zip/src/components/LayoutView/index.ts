import LayoutView from "./LayoutView";

export default LayoutView;